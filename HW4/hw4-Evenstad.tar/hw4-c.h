/****************************/
/**Ryan Evenstad Homework 2**/
/****************************/

#include "hw4.h"

void printData(int size);