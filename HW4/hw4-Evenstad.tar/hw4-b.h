/****************************/
/**Ryan Evenstad Homework 2**/
/****************************/

#include "hw4.h"

void sortByInt(int size, int selection);

void sortByFloat(int size, int selection);