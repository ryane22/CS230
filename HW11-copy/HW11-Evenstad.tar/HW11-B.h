#include "HW11.h"

int greedy(char start[84]);
