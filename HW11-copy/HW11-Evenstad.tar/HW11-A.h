#include "HW11.h"

int drunkWalk(char start[84]);
