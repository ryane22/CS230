#include "HW11.h"

int generous(char start[84]);
