#include "hw4.h"

int scan(void);
int load(int);
