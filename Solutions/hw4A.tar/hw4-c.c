#include "hw4-c.h"

void printhl(int size) {
int i;
   for (i = size-1; i >= 0; i--) {
       printf("%s %f %d %s\n", autos[i].brand, autos[i].engine, autos[i].miles, autos[i].color);
   }
}

void printlh(int size) {
int i;
   for (i = 0; i < size; i++) {
       printf("%s %f %d %s\n", autos[i].brand, autos[i].engine, autos[i].miles, autos[i].color);
   }
}

