#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef STRUCTURE
#define STRUCTURE
struct data {
   char brand[20];
   float engine;
   int miles;
   char color[20];
} temp, *autos;
#endif
