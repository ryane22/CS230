#include "hw4-b.h"

void sortf(int size) {
int i, swapped;
   do {               
      swapped = 0; 
      for (i = 0; i < size-1; i++) {
          if (autos[i].engine > autos[i+1].engine) {
             temp       = autos[i];               
             autos[i]   = autos[i+1];
             autos[i+1] = temp;
             swapped = 1; 
          }                 
      }         
    } while (swapped);
}

void sorti(int size) {
int i, swapped;
   do {               
      swapped = 0; 
      for (i = 0; i < size-1; i++) {
          if (autos[i].miles > autos[i+1].miles) {
             temp       = autos[i];               
             autos[i]   = autos[i+1];
             autos[i+1] = temp;
             swapped = 1; 
          }                 
      }         
   } while (swapped);
}

