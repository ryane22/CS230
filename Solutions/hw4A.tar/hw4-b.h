#include "hw4.h"

void sortf(int);
void sorti(int);

