#include "hw4-a.h"

int scan(void) {
int size = 0;
FILE *data;
   data = fopen("./hw4.data", "r");
   while (1) {
      fscanf(data, "%s %f %d %s", temp.brand, &temp.engine, &temp.miles, temp.color);
      if (feof(data)) break;
      size++;
   }
   return size;
}

int load(int size) {
int i;
FILE *data;
   data = fopen("./hw4.data", "r");
   for (i = 0; i < size; i++) {
      fscanf(data, "%s %f %d %s", autos[i].brand, &autos[i].engine, &autos[i].miles, autos[i].color);
   }
   return size;
}
