#include "hw4.h"
#include "hw4-a.h"
#include "hw4-b.h"
#include "hw4-a.h"

int main(void) {
int size;
char option;
    while (1) {
       printf("MENU\n");
       printf("1] Sort by float & print hi to lo.\n");
       printf("2] Sort by float & print lo to hi.\n");
       printf("3] Sort by int   & print hi to lo.\n");
       printf("4] Sort by int   & print lo to hi.\n");
       printf("5] Exit.\n");
       scanf("%c", &option);
       switch (option) {
          case '1': 
            size = scan();
            autos = calloc(size, sizeof(temp));
            load(size);
            sortf(size);
            printhl(size);
            free(autos);												
            break;
          case '2': 
            size = scan();
            autos = calloc(size, sizeof(temp));
            load(size);
            sortf(size);
            printlh(size);
            free(autos);												
            break;
          case '3': 
            size = scan();
            autos = calloc(size, sizeof(temp));
            load(size);
            sorti(size);
            printhl(size);
            free(autos);												
            break;
          case '4': 
            size = scan();
            autos = calloc(size, sizeof(temp));
            load(size);
            sorti(size);
            printlh(size);
            free(autos);												
            break;
          case '5':
             exit(1); 
       }
    }
}
