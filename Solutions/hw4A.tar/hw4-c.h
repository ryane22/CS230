#include "hw4.h"

void printhl(int);
void printlh(int);

